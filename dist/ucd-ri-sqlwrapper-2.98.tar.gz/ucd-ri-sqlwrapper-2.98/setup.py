from setuptools import setup

setup(
    name='ucd-ri-sqlwrapper',
    version='2.98',
    description='SQL tools for ',
    author='Duke LeTran',
    author_email='daletran@ucdavis.edu',
    url='https://gitlab.ri.ucdavis.edu/ri-tools/pydatautils',
    packages=['sqlwrapper'],
    classifiers=["Programming Language :: Python :: 3"],
    install_requires=[
        'pandas>=2.0.0',
        'numpy'
        'sqlalchemy>=2.0.0',
        'cx-Oracle',
        'pyodbc',
        'pymysql',
        'python-dotenv',
        'hvac',
        'openpyxl',
    ],
    python_requires='>=3.8',
    license='GPLv3'
)
